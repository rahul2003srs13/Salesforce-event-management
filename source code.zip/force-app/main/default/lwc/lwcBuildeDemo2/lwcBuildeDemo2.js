import { LightningElement , api } from "lwc";
export default class LwcBuildeDemo2 extends LightningElement {
	@api
	recordId;
	@api
	objectApiName;
}