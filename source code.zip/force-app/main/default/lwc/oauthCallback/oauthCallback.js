import { LightningElement , api } from "lwc";
export default class OauthCallback extends LightningElement {
	@api code;
}